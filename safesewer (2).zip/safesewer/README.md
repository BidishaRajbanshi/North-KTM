# SafeSewer

**No robot proof, no payment. If a human goes in, nobody gets paid.**

A hackathon prototype on MST Blockchain. A city escrows the payment for a sewer or manhole job. The contractor gets paid only when an approved robot submits a proof signed with its own device key that it did the job and no person entered the manhole. If the robot's thermal camera sees a person inside, that event is written to the chain permanently, the payment goes back to the city and the contractor's bond goes to a worker welfare fund.

We are not building a better sewer robot. Those already exist (Genrobotics' Bandicoot runs in several Indian cities). We build the proof layer that makes using one the only way to get paid.

---

## 1. The problem, in verified numbers

| Fact | Source |
|---|---|
| 498 workers died cleaning sewers and septic tanks in India from Jan 2019 to Jun 2026 (government figure given to Lok Sabha) | [Business Standard, Aug 2026](https://www.business-standard.com/india-news/sanitation-workers-sewer-septic-tank-cleaning-deaths-since-2019-126080500881_1.html) |
| 47 of those deaths were in 2025; UP (10), Haryana (7) and Tamil Nadu (6) led | [Scroll](https://scroll.in/latest/1094652/47-died-while-cleaning-sewers-septic-tanks-in-2025-says-centre) |
| The government reported 16 deaths for Jan–Jun 2026. The rights group DASAM documented 66 for Feb–Jul 2026 and says deaths get reclassified as "accidents" or "drowning" | [Business Standard](https://www.business-standard.com/india-news/sanitation-workers-sewer-septic-tank-cleaning-deaths-since-2019-126080500881_1.html), [Counterview](https://www.counterview.in/2026/07/66-sanitation-workers-died-cleaning.html) |
| Manual scavenging has been banned since the 2013 Act | [Scroll](https://scroll.in/latest/1094652/47-died-while-cleaning-sewers-septic-tanks-in-2025-says-centre) |
| The NAMASTE scheme (July 2023) exists to mechanise sanitation; 89,915 workers validated so far | [Business Standard](https://www.business-standard.com/india-news/sanitation-workers-sewer-septic-tank-cleaning-deaths-since-2019-126080500881_1.html) |

The gap: the law and the robots exist, but nobody can prove which method a contractor actually used, and deaths are easy to reclassify after the fact. **SafeSewer turns "we used a machine" from a claim into a signed, public record.**

---

## 2. How it works

```
 City (BBMP)                 Contractor                    Robot (Raspberry Pi)
     │ registerRobot(robot)      │ depositBond(0.5 MSTC)        │
     │ postJob(manhole, 1 MSTC) ─┼──────────── escrow ──────────┤
     │                           │                              │ 1. read manhole NFC tag
     │                           │                              │ 2. log H2S, thermal, depth, motor current
     │                           │                              │ 3. hash evidence bundle
     │                           │                              │ 4. SIGN proof with robot key
     │                           │      submitProof(proof, sig) ◄┘
     │                     SafeSewer contract checks:
     │                       • signer is a robot registered to this contractor
     │                       • right manhole, ran long enough, evidence not reused
     │                       • humanDetected?
     │               ┌──────────────┴──────────────┐
     │          no human                       human inside
     │   challenge window → Paid          HumanEntryDetected (permanent)
     │   (inspector can dispute)          payment → city, bond → welfare fund
```

**Why blockchain and not a government database?** The city, the contractor, workers' groups and the public don't trust each other, and the party that could edit a database is the one with the most to hide. Here the robot's signature can't be forged, the record can't be quietly reclassified later, anyone can audit it on MSTScan, and payment releases automatically with no official who can be pressured.

---

## 3. What's in this folder

| Path | What it is |
|---|---|
| `contracts/SafeSewer.sol` | The escrow contract. |
| `test/SafeSewer.test.js` | 8 tests: payment, fake robot, tampered data, wrong manhole, too-short run, replay, human entry and slashing, dispute, deadline refund. All pass. |
| `scripts/deploy.js` | Deploys, registers the robot, bonds the contractor, posts job #1. Writes `deployment.json`. |
| `scripts/new-job.js`, `scripts/release.js` | Post another job; release payment after the challenge window. |
| `robot/robot_agent.py` | Runs on the Pi. Real sensors, or `--mock` on a laptop. Uses the MST Python SDK. |
| `dashboard/index.html` | Control-room screen for the pitch (simulation, works offline). |

---

## 4. Hardware (bill of materials)

Prices change, so check Robu.in or Robocraze before ordering.

| Part | Job in the proof | Notes |
|---|---|---|
| Raspberry Pi 4 or 5 (+ 32 GB SD, 5V 3A supply) | Brain. Holds the robot's key and signs proofs | Pi Zero 2 W also works but is slower |
| **MLX90640 thermal camera (32×24)** | **Human detection** — the core of the idea | Cheaper option: AMG8833 (8×8); set `HUMAN_MIN_PIXELS` to about 3 |
| MQ-136 H₂S gas sensor | Shows how lethal the site was | Needs calibration against a reference meter. Hackathon values are indicative only |
| ADS1115 ADC module | Pi has no analog input; reads the MQ-136 | |
| PN532 NFC reader + NTAG tags | Ties the proof to one physical manhole | Production: NTAG 424 DNA (tags that produce a fresh signed code on each tap) |
| INA219 current sensor | Proves the motors actually ran | In series with the drive motor supply |
| JSN-SR04T waterproof ultrasonic | Sludge level before and after | Echo is 5V: use a 1k/2k voltage divider to the Pi |
| Pi Camera module | Before and after photos in the evidence bundle | |
| Buzzer | Gas or human alarm | |
| Chassis: tank-track kit + L298N driver + 2 geared motors, **or** a winch-lowered sensor pod | The "robot" | A pod lowered on a cord into a pipe is faster to build and demos just as well |
| Mock manhole | Stage prop | A 40–60 cm PVC pipe or big bucket, with a printed "BBMP MH-0417" plate and the NFC tag stuck on the rim |

### Wiring

All I2C devices share SDA (GPIO2, pin 3) and SCL (GPIO3, pin 5). Addresses don't clash:

| Device | Bus / pin | Address |
|---|---|---|
| ADS1115 | I2C | 0x48 |
| MLX90640 | I2C | 0x33 |
| INA219 | I2C | 0x40 |
| PN532 (set DIP switches to I2C) | I2C | 0x24 |
| MQ-136 AO | ADS1115 A0 (through a divider if the module outputs 5V) | |
| JSN-SR04T | TRIG GPIO23, ECHO GPIO24 (divider) | |
| Buzzer | GPIO18 | |

Pi setup: `sudo raspi-config` → Interface → enable I2C and camera. For MLX90640, set `dtparam=i2c_arm_baudrate=400000` in `/boot/firmware/config.txt`.

```bash
pip install mst-sdk-python eth-abi adafruit-blinka adafruit-circuitpython-ads1x15 \
  adafruit-circuitpython-mlx90640 adafruit-circuitpython-ina219 adafruit-circuitpython-pn532 gpiozero picamera2
```

---

## 5. Run it

**Fastest: `node scripts/demo-all.js` (or double-click START-DEMO) runs everything. Step-by-step for VS Code: [RUN-IN-VSCODE.md](RUN-IN-VSCODE.md).**

**Chain:** MST testnet, chain ID `91562037`, RPC `https://testnetrpc.mstblockchain.com` (both taken from the MST Python SDK's own constants).

Quick version, local practice chain (no wallet needed):

```bash
npm install && python -m pip install -r robot/requirements.txt
npm run chain                                        # terminal 1, leave running
npm run deploy:local                                 # terminal 2
python robot/robot_agent.py --mock                   # clean job
npm run release:local                                # contractor paid
npm run job:local
python robot/robot_agent.py --mock --scenario human  # human entry
npm run status:local
```

Real MST testnet: fill `.env` from `.env.example`, then the same commands with `:testnet` instead of `:local`. Every transaction can be checked on [MSTScan](https://mstscan.com). The robot script prints `mstscan.com/tx/<hash>`; confirm that URL format works on the day.

**Tested here:** the contract suite (8/8 passing) and the full robot flow, both scenarios, against a local Hardhat chain. **Not tested here:** the live MST testnet (the build machine couldn't reach its RPC) and the real sensor drivers (no hardware). Deploy to testnet and run each sensor on its own the day before.

**Never commit** `robot/robot.key` or any private key. `.gitignore` covers the key file.

---

## 6. The 3-minute demo

1. **(30 s) The number.** "498 people died in Indian sewers since 2019, by the government's own count. For early 2026 the government reported 16 deaths; a rights group documented 66 and says deaths get relabelled as accidents. Robots exist. Contractors skip them because nothing forces them."
2. **(45 s) Clean job, live.** Tap the NFC tag, lower the pod into the pipe. The dashboard and terminal stream H₂S and thermal readings. The proof goes on-chain; show the MSTScan link. After the window, the contractor is paid.
3. **(45 s) Human entry, with a judge.** Ask a judge to lean over the pipe or put a hand in front of the thermal camera. The alarm goes off, `HumanEntryDetected` hits the chain, payment goes back to the city and the bond goes to the welfare fund. "The moment a person goes in, the contractor loses money. It's recorded forever and nobody can call it an accident later."
4. **(30 s) Tamper test.** Press "Tamper with log" on the dashboard (or edit a value in the manifest and resubmit). The contract rejects it with `BadSigner`.
5. **(30 s) Why this scales.** "Cities already pay for robots under NAMASTE. We plug in as a small black box on any robot, and payment rules the city already wants become automatic."

---

## 7. Questions judges will ask

- **"Why blockchain?"** The city, contractors and the public don't trust each other, and whoever runs a database can edit it. The robot's signature can't be faked, the record can't be relabelled, and payment needs no official's sign-off.
- **"Can't the contractor just not submit the human-entry proof?"** Yes, and then they don't get paid. The only way to get paid is a signed proof with no human in it. Silence costs them the job.
- **"Can't they run the robot in a bucket and send a man in the real sewer?"** The NFC tag ties the proof to one manhole. In production, the tag would be an NTAG 424 DNA that produces a fresh signed code each tap, plus a GPS geofence, plus inspectors' random audits within the challenge window. The robot's key would sit in a secure chip (ATECC608A) so it can't be copied off the Pi. We say this plainly as the production roadmap.
- **"Can they cover the thermal camera?"** A blocked or constant camera frame is itself detectable (no variance, no pipe-wall gradient). That check is on the roadmap, not in the prototype.
- **"Gas sensor accuracy?"** MQ-series sensors are indicative, not certified. Production would use an electrochemical H₂S cell. The payment rule doesn't depend on the gas number; it's there as evidence of danger.
- **"Why MST?"** EVM-compatible, so standard Solidity and tooling. Low fees matter because every job is a transaction. The Python SDK runs on the Pi, so the robot signs and submits by itself.

---

## 8. Honest limits of the prototype

- The human check is a heat threshold, not a trained model. Tune `HUMAN_TEMP_C` and `HUMAN_MIN_PIXELS` on site; a hot pipe on a Bengaluru afternoon can read warm.
- The dashboard is a simulation for the pitch. The on-chain proof is real only through the robot script.
- Evidence files are hashed and kept on the Pi. Pinning them to IPFS is a small addition if time allows.
