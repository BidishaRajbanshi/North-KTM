# Run SafeSewer in VS Code

Two ways to run it:

- **Part A — Local demo.** Runs 100% on your laptop. No wallet, no faucet, no internet chain. Do this first.
- **Part B — Real MST testnet.** Same code on the real chain, with MSTScan links for the judges.

---

## Step 1. Install these once

| Tool | Get it | Check it worked (in a terminal) |
|---|---|---|
| VS Code | code.visualstudio.com | — |
| Node.js **20 or 22 LTS** | nodejs.org → LTS installer | `node -v` |
| Python **3.10 to 3.12** | python.org. On Windows, **tick "Add python.exe to PATH"** on the first installer screen | `python --version` |

Restart VS Code after installing Node and Python so it picks them up.

## Step 2. Open the project

1. Unzip `safesewer.zip`. You get a folder called `safesewer`.
2. VS Code → **File → Open Folder…** → select that `safesewer` folder. Open the folder itself, not a file inside it and not its parent.
3. VS Code will offer to install recommended extensions (Python, Solidity, Live Server). Click **Install**.
4. Press `Ctrl+Shift+P` → type **Python: Select Interpreter** → pick your Python 3.10–3.12.

## Step 3. Run the whole thing (one command)

In VS Code: **Terminal → New Terminal**, then type:

```
node scripts/demo-all.js
```

Or skip VS Code: double-click **`START-DEMO.bat`** (Windows) or **`START-DEMO.command`** (Mac; if blocked, right-click → Open → Open).

It does everything by itself, in 7 stages:

1. Checks Node and Python.
2. Installs packages (first run only, 2–5 minutes, needs internet).
3. Runs the 8 contract tests.
4. Starts a local blockchain on your laptop.
5. Deploys the contract.
6. Runs a clean robot job, and the contractor gets paid.
7. Runs a human entry, and the payment is blocked.

It ends with **`✔ Everything ran.`** and the local blockchain shuts down on its own. Run it as many times as you like.

For the pitch screen, open `dashboard/index.html` in Chrome.

The steps below do the same thing one piece at a time, which is useful when presenting live.

## Step 3b. Install packages by hand (optional)

**Terminal → Run Task… → `0 · Install everything (first time only)`**

Or type it yourself in **Terminal → New Terminal**:

```
npm install
python -m pip install -r robot/requirements.txt
```

(Mac: use `python3` instead of `python`.)

---

## Part A — Local demo

All steps are under **Terminal → Run Task…**. Run them in this order.

| # | Task | What you'll see |
|---|---|---|
| 1 | `1 · Start local blockchain (leave running)` | A list of 20 test accounts, then `Started HTTP and WebSocket JSON-RPC server at http://127.0.0.1:8545/`. **Keep this terminal open.** If you close it, the chain is gone and you start again from 1. |
| 2 | `2 · Deploy contract (local)` | `SafeSewer 0x5FbDB…`, `job #1 posted`, `wrote deployment.json` |
| 3 | `3 · Robot: clean job (mock sensors)` | 20 lines of live H₂S / thermal / depth / motor readings, then `status=OK` and `Proof accepted` |
| 4 | `4 · Release payment (waits for challenge window)` | Waits about 10 s, then `job #1 PAID: contractor +1.0 MSTC` |
| 5 | `5 · Post a new job (local)` | `job #2 posted` |
| 6 | `6 · Robot: HUMAN ENTRY scenario` | Readings, then `HUMAN DETECTED`, then `HUMAN ENTRY recorded on-chain. Payment refunded to city, contractor bond slashed.` |
| — | `Show contract status (local)` | Job #1 Paid, job #2 HumanEntry, welfare fund 0.5 MSTC |
| — | `Run contract tests` | `8 passing` |
| — | `Open demo dashboard in browser` | The control-room screen for your pitch. You can also right-click `dashboard/index.html` → **Open with Live Server**. |

**Same thing typed by hand** (two terminals; click **+** in the terminal panel for the second):

```
# Terminal 1 — leave it running
npm run chain

# Terminal 2
npm run deploy:local
python robot/robot_agent.py --mock
npm run release:local
npm run job:local
python robot/robot_agent.py --mock --scenario human
npm run status:local
```

**Every robot run needs a fresh job.** A job accepts one proof only. That's the anti-replay rule working, not a bug. Run `npm run job:local` between robot runs.

---

## Part B — Real MST testnet

1. **Make the robot wallet:** `python robot/robot_agent.py --new-key`. Copy the address it prints.
2. **Make two more wallets** in the BridgeKey extension: one for the **city**, one for the **contractor**. Export their private keys.
3. **Get test MSTC** from faucet.masterstroke.academy for all three addresses. The robot needs a little for gas, the contractor needs 0.5+ for the bond, and the city needs 1+ per job.
4. **Create `.env`:** copy `.env.example`, rename the copy to `.env` and fill in the three values. Never share this file.
5. Run:

```
npm run deploy:testnet
python robot/robot_agent.py --mock          # prints an mstscan.com link
npm run release:testnet                     # waits out the 60 s window
npm run job:testnet
python robot/robot_agent.py --mock --scenario human
npm run status:testnet
```

On the real Raspberry Pi, drop `--mock` and install `robot/requirements-pi.txt` there (wiring is in README section 4).

---

## If something goes wrong

| Error | Fix |
|---|---|
| `npm : running scripts is disabled on this system` (Windows) | In PowerShell run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, answer `Y`, and restart VS Code. Or switch the terminal to Command Prompt with the **⌄** next to **+**. |
| `'python' is not recognized` | Python isn't on PATH. Reinstall and tick "Add to PATH", or use `py` instead of `python`. Mac: use `python3`. |
| `ModuleNotFoundError: No module named 'mst_blockchain_sdk'` | Packages went into a different Python. Run `python -m pip install -r robot/requirements.txt` using the same `python` you run the robot with. |
| `ECONNREFUSED 127.0.0.1:8545` or `connection refused` | The local chain isn't running. Start task 1 (or `npm run chain`) and keep it open. |
| `ENOENT … deployment.json` | You haven't deployed yet. Run task 2. |
| `Contract rejected the proof … BadStatus` | That job already has a proof. Run task 5 (`npm run job:local`). |
| Anything fails after restarting the chain | Restarting wipes the local chain. Run task 2 again, then continue. |
| `HH502: Couldn't download compiler` | First compile needs internet to fetch Solidity 0.8.24. Connect and retry. |
| `insufficient funds` (testnet only) | Top up that wallet from the faucet. |
| `No deployer key` (testnet only) | `.env` is missing or still says `0x`. See Part B step 4. |

## What's in the folder

```
safesewer/
├─ contracts/SafeSewer.sol      the smart contract
├─ test/                        8 automated tests
├─ scripts/                     deploy, new job, release, status
├─ robot/robot_agent.py         robot program (mock or real sensors)
├─ dashboard/index.html         pitch-screen simulation
├─ .vscode/tasks.json           the Run Task menu
├─ .env.example                 template for testnet keys
├─ START-DEMO.bat / .command    double-click to run everything
└─ README.md                    idea, hardware, wiring, pitch, judge Q&A
```
